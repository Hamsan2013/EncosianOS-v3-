# EncosianOS

Custom Raspberry Pi OS image for Raspberry Pi 3.

- Installs nginx
- Serves the Encosian website automatically

## Usage
- Build runs via GitHub Actions.
- Output image available in workflow artifacts.
- Flash with Raspberry Pi Imager using "Use custom OS".
